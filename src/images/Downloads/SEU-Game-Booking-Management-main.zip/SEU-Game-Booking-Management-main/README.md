# SEU-Game-Booking-Management

- Create a file name as .env
- Copy the all information from .env-example and past it .env file
- Create a database name as games_room
- Open command terminal and navigate below command
- php artisan migrate:fresh --seed
- php artisan serve
